﻿namespace MindCheckData;

public class Class1
{

}
