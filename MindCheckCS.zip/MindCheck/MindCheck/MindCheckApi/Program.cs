using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Mvc;
using MindCheckData;

var builder = WebApplication.CreateBuilder(args);


// Configuração do Banco (Oracle)

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseOracle(builder.Configuration.GetConnectionString("DefaultConnection")));


// Serviços da Aplicação
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddControllers();


// API VERSIONING (v1 como padrão)
builder.Services.AddApiVersioning(options =>
{
    options.DefaultApiVersion = new ApiVersion(1, 0);     
    options.AssumeDefaultVersionWhenUnspecified = true;    
    options.ReportApiVersions = true;                      
});


// Swagger / OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();


// Ativa Swagger
app.UseSwagger();
app.UseSwaggerUI();


// Controllers + Rotas
app.MapControllers();


// Executa a aplicação
app.Run();
