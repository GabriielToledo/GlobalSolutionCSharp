using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

// Versão da API
[ApiVersion("1.0")]

// Rota com versionamento
[Route("api/v{version:apiVersion}/[controller]")]
[ApiController]
public class UserController : ControllerBase
{
    private readonly IUserService _userService;

    // Injeção de Dependência da interface do serviço
    public UserController(IUserService userService)
    {
        _userService = userService;
    }

    // GET: api/v1/User
    [HttpGet]
    public async Task<ActionResult<IEnumerable<User>>> GetUsers()
    {
        var users = await _userService.GetAllAsync();
        return Ok(users);
    }

    // GET: api/v1/User/{id}
    [HttpGet("{id}")]
    public async Task<ActionResult<User>> GetUser(Guid id)
    {
        var user = await _userService.GetByIdAsync(id);

        if (user == null)
        {
            return NotFound();
        }

        return Ok(user);
    }

    // POST: api/v1/User
    [HttpPost]
    public async Task<ActionResult<User>> PostUser(User user)
    {
        var newUser = await _userService.AddAsync(user);

        return CreatedAtAction(nameof(GetUser), new { id = newUser.Id }, newUser);
    }

    // PUT: api/v1/User/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> PutUser(Guid id, User user)
    {
        if (id != user.Id)
        {
            return BadRequest(new { message = "O ID da rota não corresponde ao ID da requisição." });
        }

        var updatedUser = await _userService.UpdateAsync(user);

        if (updatedUser == null)
        {
            return NotFound();
        }

        return NoContent();
    }

    // DELETE: api/v1/User/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteUser(Guid id)
    {
        var isDeleted = await _userService.DeleteAsync(id);

        if (!isDeleted)
        {
            return NotFound();
        }

        return NoContent();
    }
}
