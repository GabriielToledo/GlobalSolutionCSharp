﻿namespace MindCheckBusiness;

public class Class1
{

}
