using System;
using System.Collections.Generic;
using System.Threading.Tasks;

// Crie este arquivo em uma pasta como 'Services' ou 'Interfaces'
public interface IUserService
{
    Task<IEnumerable<User>> GetAllAsync();
    Task<User?> GetByIdAsync(Guid id);
    Task<User> AddAsync(User user);
    Task<User?> UpdateAsync(User user);
    Task<bool> DeleteAsync(Guid id);
}