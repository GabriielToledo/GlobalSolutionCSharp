﻿namespace MindCheckModel;

public class Class1
{

}
